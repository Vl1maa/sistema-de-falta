package com.api.sistemafalta.modelos.materia;

public class NovaMateriaDTO {
    private String descricao;

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
