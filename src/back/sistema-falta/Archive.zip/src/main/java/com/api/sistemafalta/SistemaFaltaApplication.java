package com.api.sistemafalta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaFaltaApplication {
	public static void main(String[] args) {
		SpringApplication.run(SistemaFaltaApplication.class, args);
	}
}
